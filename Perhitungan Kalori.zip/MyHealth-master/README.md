# MyHealth

MyHealth merupakan sebuah aplikasi panduan hidup sehat berbasis android yang memiliki berbagai fungsi seperti membantu user dalam mengatur jumlah kalori yang dibutuhkan sehari-hari, memprediksi kadar lemak, serta mengukur berat badan ideal dan indeks massa tubuh. 

MyHealth memiliki beberapa kelebihan diantaranya MyHealth bisa melakukan perhitungan Berat Badan Ideal dan Indeks Massa Tubuh user dengan mudah (user hanya perlu memasukkan berat badan dan tinggi badan pada saat registrasi). 

User juga bisa melihat track record BBI dan IMT nya secara berkala. 

Selain itu MyHealth memiliki fitur perhitungan kalori harian untuk menentukan kebutuhan kalori user berdasarkan level aktivitas yang dilakukan. Tentunya hal ini membantu user mencegah terjadinya kelebihan atau kekurangan kalori. 

Fitur yang digunakan untuk memprediksi kadar lemak pada MyHealth membantu user untuk memantau kadar lemaknya untuk mencegah penyakit yang timbul akibat kelebihan kadar lemak.

Di sisi lain selain dari segi usabilitas, MyHealth memiliki tampilan User Interface yang simple dan menarik. Desain MyHealth dirancang untuk memberikan kemudahan penggunaan bagi user awam sekaligus.
